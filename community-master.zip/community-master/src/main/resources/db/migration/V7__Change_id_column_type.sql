alter table question modify id bigint NOT NULL;
alter table `user` modify id bigint NOT NULL;